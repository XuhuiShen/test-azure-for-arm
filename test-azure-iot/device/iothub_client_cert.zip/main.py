#! /usr/bin/env python
import os

os.system('python ./iothub_client_sample.py -c "HostName=IOT-nostalgia.azure-devices.cn;DeviceId=sample;SharedAccessKey=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" -p mqtti')
